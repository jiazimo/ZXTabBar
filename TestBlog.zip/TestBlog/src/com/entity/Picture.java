package com.entity;

import java.sql.Blob;

public class Picture {
	
	private int id;
	private Blob blob;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Blob getBlob() {
		return blob;
	}
	public void setBlob(Blob blob) {
		this.blob = blob;
	}

}
