package com.dao;

import java.util.List;

import com.entity.User;

public interface UserDao {
	
	public int addUser(User user);
	
	public User selectUserByName(String username);
	
	public List<User> selectAllUser();
	
	public User selectUserById(int id);
	
	public int updateUserById(User user);
	
	public int delUserById(int id);
	
	public List<String> selectUsername();
	
	public List<String> selectPassword();
	

}
