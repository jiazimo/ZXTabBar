package com.dao;

import com.entity.Picture;

public interface PicDao {
	
	public int addPic(Picture picture);

}
