package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dao.ArticleDao;
import com.entity.Title;
import com.tools.Tools;

public class ArticleDaoImpl implements ArticleDao {

	@Override
	public int addArticle(Title title) {
		Connection con=Tools.getConnection();
		int rs=0;
		String sql="insert into article (title,author,kind,time,info,path) values(?,?,?,?,?,?)";
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, title.getTitle());
			pstmt.setString(2, title.getAuthor());
			pstmt.setString(3, title.getKind());
			pstmt.setString(4, title.getDate());
			pstmt.setString(5, title.getInfo());
			pstmt.setString(6, title.getFilepath());
			rs=pstmt.executeUpdate();
			Tools.closeAll(pstmt, null, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return rs;
	}

	@Override
	public List<Title> selectAll() {
		// TODO Auto-generated method stub
		List<Title> list=new ArrayList();
		Connection con=Tools.getConnection();
		String sql="select * from article";
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			Title t=null;
			while(rs.next()){
				t=new Title();
				int id=rs.getInt("article_id");
				String title=rs.getString("title");
				String author=rs.getString("author");
				String kind=rs.getString("kind");
				String time=rs.getString("time");
				String info=rs.getString("info");
				String filepath=rs.getString("path");
				t.setId(id);
				t.setTitle(title);
				t.setAuthor(author);
				t.setKind(kind);
				t.setDate(time);
				t.setInfo(info);
				t.setFilepath(filepath);
				list.add(t);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Title selectTitleById(int id) {
		Connection con=Tools.getConnection();
		String sql="select * from article where article_id=?";
		ResultSet rs=null;
		Title t=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			while(rs.next()){
				t=new Title();
				int ids=rs.getInt("article_id");
				String title=rs.getString("title");
				String author=rs.getString("author");
				String kind=rs.getString("kind");
				String time=rs.getString("time");
				String info=rs.getString("info");
				String filepath=rs.getString("path");
				t.setId(ids);
				t.setTitle(title);
				t.setAuthor(author);
				t.setKind(kind);
				t.setDate(time);
				t.setInfo(info);
				t.setFilepath(filepath);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return t;
	}

	@Override
	public String selectPathById(int id) {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		String sql="select path from article where article_id=? ";
		String path=null;
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			if(rs.next()){
			path=rs.getString("path");
			}
			Tools.closeAll(pstmt, rs, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return path;
	}

	@Override
	public int delById(int id) {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		String sql="delete from article where article_id=?";
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeUpdate();
			Tools.closeAll(pstmt, null, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	public int updateTitle(Title title) {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		int rs=0;
		String sql="update article set title=?,author=?,kind=?,time=?,info=? where article_id=?";
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, title.getTitle());
			pstmt.setString(2, title.getAuthor());
			pstmt.setString(3, title.getKind());
			pstmt.setString(4, title.getDate());
			pstmt.setString(5, title.getInfo());
			pstmt.setInt(6, title.getId());
			rs=pstmt.executeUpdate();
			Tools.closeAll(pstmt, null, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	

}
