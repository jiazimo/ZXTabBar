package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dao.InfoDao;
import com.entity.Info;
import com.tools.Tools;

public class InfoDaoImpl implements InfoDao {

	@Override
	public int addInfo(Info info) {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		String sql="insert into info (message) values(?)";
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, info.getInfo());
			rs=pstmt.executeUpdate();
			Tools.closeAll(pstmt, null, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	public List<Info> selectAll() {
		// TODO Auto-generated method stub
		List<Info> list=new ArrayList<Info>();
		Connection con=Tools.getConnection();
		String sql="select * from info";
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();				
			Info info=null;
			while(rs.next()){
				int id=rs.getInt("info_id");
				String message=rs.getString("message");
				info=new Info();
				info.setId(id);
				info.setInfo(message);
				list.add(info);
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
		
	}

	@Override
	public int delInfo(int id) {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		String sql="delete from info where info_id=?";
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,id);
			rs=pstmt.executeUpdate();
			Tools.closeAll(pstmt, null, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
}
