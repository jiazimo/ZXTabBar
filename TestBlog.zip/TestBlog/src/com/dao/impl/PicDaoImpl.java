package com.dao.impl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.dao.PicDao;
import com.entity.Picture;
import com.tools.Tools;

public class PicDaoImpl implements PicDao {

	@Override
	public int addPic(Picture picture) {
		Connection con=Tools.getConnection();
		String sql="insert into pic (picture) values(?)";
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setBlob(1, picture.getBlob());
			rs=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return rs;
	}

}
