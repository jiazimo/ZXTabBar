package com.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dao.UserDao;
import com.entity.User;
import com.tools.Tools;

public class UserDaoImpl implements UserDao {

	

	@Override
	public int addUser(User user) {
		Connection con=Tools.getConnection();
		String sql="insert into user (username,userpass,sex,date) values(?,?,?,?)";
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getSex());
			pstmt.setString(4, user.getDate());
			rs=pstmt.executeUpdate();
			Tools.closeAll(pstmt, null, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	public User selectUserByName(String username) {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		String sql="select userpass from user where username=?";
		ResultSet rs=null;
		User user=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, username);
			rs=pstmt.executeQuery();
			if(rs.next()){
				user=new User();
				String password=rs.getString("userpass");
				user.setPassword(password);
			}
			Tools.closeAll(pstmt, rs, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public List<User> selectAllUser() {
		List<User> list=new ArrayList<User>();
		Connection con=Tools.getConnection();
		String sql="select * from user";
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			User user=null;
			while(rs.next()){
				user=new User();
				int id=rs.getInt("u_id");
				String name=rs.getString("username");
				String pass=rs.getString("userpass");
				String sex=rs.getString("sex");
				String date=rs.getString("date");
				user.setId(id);
				user.setUsername(name);
				user.setPassword(pass);
				user.setSex(sex);
				user.setDate(date);
				list.add(user);
			}
			Tools.closeAll(pstmt, rs, con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	@Override
	public User selectUserById(int id) {
		Connection con=Tools.getConnection();
		String sql="select * from user where u_id=?";
		User user=null;
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,id);
			rs=pstmt.executeQuery();
			while(rs.next()){
				user=new User();
				int ids=rs.getInt("u_id");
				String name=rs.getString("username");
				String pass=rs.getString("userpass");
				String sex=rs.getString("sex");
				String date=rs.getString("date");
				user.setId(ids);
				user.setUsername(name);
				user.setPassword(pass);
				user.setSex(sex);
				user.setDate(date);				
			}
			Tools.closeAll(pstmt, rs, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return user;
	}

	@Override
	public int updateUserById(User user) {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		String sql="update user set username=?,userpass=?,sex=?,date=? where u_id=?";
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, user.getUsername());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getSex());
			pstmt.setString(4, user.getDate());
			pstmt.setInt(5, user.getId());
			rs=pstmt.executeUpdate();
			Tools.closeAll(pstmt, null, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	public int delUserById(int id) {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		String sql="delete from user where u_id=?";
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeUpdate();
			Tools.closeAll(pstmt, null, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}

	@Override
	public List<String> selectUsername() {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		List<String> list=new ArrayList();
		String sql="select username from user";
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()){
				String username=rs.getString("username");
				list.add(username);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<String> selectPassword() {
		// TODO Auto-generated method stub
		Connection con=Tools.getConnection();
		List<String> list=new ArrayList();
		String sql="select userpass from user";
		ResultSet rs=null;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()){
				String username=rs.getString("userpass");
				list.add(username);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
}
