package com.dao;

import java.util.List;

import com.entity.Info;

public interface InfoDao {
	
	public int addInfo(Info info);
	
	public List<Info> selectAll();
	
	public int delInfo(int id);

}
