package com.dao;

import java.util.List;

import com.entity.Title;

public interface ArticleDao {
	public int addArticle(Title title);
	
	public List<Title> selectAll();
	
	public Title selectTitleById(int id);
	
	public String selectPathById(int id);
	
	public int delById(int id);
	
	public int updateTitle(Title title);

}
