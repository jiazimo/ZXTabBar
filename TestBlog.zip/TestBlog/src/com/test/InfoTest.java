package com.test;

import static org.junit.Assert.fail;

import org.junit.Test;

import com.dao.InfoDao;
import com.dao.impl.InfoDaoImpl;
import com.entity.Info;

public class InfoTest {
	
	private static  InfoDao infodao=new InfoDaoImpl();

	@Test
	public void testAddInfo() {
		Info info=new Info();
		info.setInfo("hello!");
		infodao.addInfo(info);
	}

	@Test
	public void testSelectAll() {
		infodao.selectAll();
		
	}

}
