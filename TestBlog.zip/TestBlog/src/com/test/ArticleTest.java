package com.test;

import static org.junit.Assert.fail;

import org.junit.Test;

import com.dao.ArticleDao;
import com.dao.impl.ArticleDaoImpl;
import com.entity.Title;

public class ArticleTest {
	
	private ArticleDao articledao=new ArticleDaoImpl();
	@Test
	public void testAddArticle() {
		Title t=new Title();
		t.setTitle("1");
		articledao.addArticle(t);
	}

	@Test
	public void testSelectAll() {
		articledao.selectAll();
	}

	@Test
	public void testSelectTitleById() {
		articledao.selectPathById(6);
	}

	@Test
	public void testSelectPathById() {
		articledao.selectPathById(6);
	}

	@Test
	public void testUpdateTitle() {
		Title t=new Title();
		t.setId(9);
		t.setTitle("13");
		articledao.addArticle(t);
		articledao.updateTitle(t);
	}
	
	@Test
	public void testDelById() {
		articledao.delById(9);
	}



}
