package com.test;

import static org.junit.Assert.fail;

import org.junit.Test;

import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;
import com.entity.User;

public class UserTest {
	 
	private UserDao userdao=new UserDaoImpl();
	@Test
	public void testAddUser() {
		User user=new User();
		user.setUsername("zhangsan");
	}

	@Test
	public void testSelectUserByName() {
		userdao.selectUserByName("zhangsan");
	}

	@Test
	public void testSelectAllUser() {
		userdao.selectAllUser();
	}

	@Test
	public void testSelectUserById() {
		userdao.selectUserById(4);
	}

	@Test
	public void testUpdateUserById() {
		User user=new User();
		user.setId(4);
		user.setUsername("lisi");
		userdao.updateUserById(user);
		
	}

	@Test
	public void testDelUserById() {
		userdao.delUserById(4);
	}

	@Test
	public void testSelectUsername() {
		userdao.selectUsername();
	}

	@Test
	public void testSelectPassword() {
		userdao.selectPassword();
	}

}
