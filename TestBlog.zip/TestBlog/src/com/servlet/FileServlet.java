package com.servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ArticleDao;
import com.dao.impl.ArticleDaoImpl;
import com.entity.Title;
import com.jspsmart.upload.SmartUpload;

/**
 * Servlet implementation class FileServlet
 */
@WebServlet("/FileServlet")
public class FileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String filePath = "D:\\images";  
        File file = new File(filePath);  
        System.out.println(filePath);
        if(!file.exists()){  
            file.mkdir();  
        }  
        SmartUpload smartUpload = new SmartUpload();  
        //初始化对象  
        smartUpload.initialize(getServletConfig(), request, response);  
        //设置上传文件  
        smartUpload.setMaxFileSize(1024*1024*10);  
        //设置所有文件的大小  
        smartUpload.setTotalMaxFileSize(1024*1024*100); 
        //设置文件的类型  
        smartUpload.setAllowedFilesList("txt,jpg,gif");  
        String result = "上传成功！";  
        //设置禁止上传的文件类型  
        try {  
            smartUpload.setDeniedFilesList("rar,jsp,js");  
            //上传文件  
            smartUpload.upload();  
            //保存文件  
            int count = smartUpload.save(filePath);       
        } catch (Exception e) {  
            //捕捉Exception异常 ，不然捕捉到异常  
            result = "上传失败！";  
            if(e.getMessage().indexOf("1015") != -1){  
                result = "上传失败：上传文件类型不正确！";  
            }else if (e.getMessage().indexOf("1010") != -1) {  
                result = "上传失败：上传文件类型不正确！";  
            }else if (e.getMessage().indexOf("1105") != -1) {  
                result = "上传失败：上传文件大小大于允许上传的最大值！";  
            }else if (e.getMessage().indexOf("1110") != -1) {  
                result = "上传失败：上传文件总大小大于允许上传总大小的最大值！";  
            }  
            e.printStackTrace();  
        }  
         String filename=smartUpload.getFiles().getFile(0).getFileName();
         System.out.println(filename);
         String filespath=filePath+File.separator+filename;
         System.out.println(filespath);
         String title=smartUpload.getRequest().getParameter("title");
         String author=smartUpload.getRequest().getParameter("author");
         String kind=smartUpload.getRequest().getParameter("kind");
         String date=smartUpload.getRequest().getParameter("time");
         String info=smartUpload.getRequest().getParameter("message");
         Title t=new Title();
         t.setTitle(title);
         t.setAuthor(author);
         t.setKind(kind);
         t.setDate(date);
         t.setInfo(info);
         t.setFilepath(filespath);
         ArticleDao articledao=new ArticleDaoImpl();
         int rs=articledao.addArticle(t);   
         System.out.println(title);
        //获取上传文件的属性  
        for(int i=0;i<smartUpload.getFiles().getCount();i++){  
            com.jspsmart.upload.File tempFile = smartUpload.getFiles().getFile(i);  
            System.out.println("***************");  
            System.out.println("表单中name的值："+tempFile.getFileName());  
            System.out.println("上传文件名："+tempFile.getFileName());  
            System.out.println("上传文件大小："+tempFile.getSize());  
            System.out.println("上传文件的拓展名："+tempFile.getFileExt());  
            System.out.println("上传文件全名："+tempFile.getFilePathName());  
            System.out.println("***************");  
        }
        System.out.println("上传结果："+result); 
        if(rs!=0){
        	response.sendRedirect("article.jsp");
        }
        
	}

}
