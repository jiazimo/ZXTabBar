package com.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;
import com.entity.User;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		UserDao userdao=new UserDaoImpl();
		request.setCharacterEncoding("UTF-8");
		String method=request.getParameter("method");
		if(method.equals("selectById")){
			String id=request.getParameter("id");
			int ids=Integer.parseInt(id);
			User user=userdao.selectUserById(ids);
			request.setAttribute("user", user);
			request.getRequestDispatcher("info.jsp").forward(request, response);
		}else if(method.equals("delUserById")){
			String id=request.getParameter("id");
			int ids=Integer.parseInt(id);
			int rs=userdao.delUserById(ids);
			if(rs!=0){
				response.sendRedirect("about.jsp");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		UserDao userdao=new UserDaoImpl();
		request.setCharacterEncoding("UTF-8");
		String method=request.getParameter("method");
		System.out.println(method);
		if(method.equals("add")){
			String username=request.getParameter("username");
			String userpass=request.getParameter("userpassword");
			String sex=request.getParameter("sex");
			String date=request.getParameter("userdate");
			User user=new User();
			user.setUsername(username);
			user.setPassword(userpass);
			user.setSex(sex);
			user.setDate(date);
			int rs=userdao.addUser(user);
			if(rs!=0){
			response.sendRedirect("loginUser.jsp");
			}
		}else if(method.equals("select")){
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			if(UserServlet.equalsUsername(username)){
				if(UserServlet.equalsPassword(password)){
					response.sendRedirect("error.jsp");
				}else if(!UserServlet.equalsPassword(password)){
					response.sendRedirect("error.jsp");
				}
			}else{
			User user=userdao.selectUserByName(username);
			if(password.equals(user.getPassword())){
				request.getRequestDispatcher("index.html").forward(request, response);
			}else{
				response.sendRedirect("error.jsp");
			}
		}
			
		}else if(method.equals("update")){
			String id=request.getParameter("id");
			int ids=Integer.parseInt(id);
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			String sex=request.getParameter("sex");
			String date=request.getParameter("date");
			User user=new User();
			user.setId(ids);
			user.setUsername(username);
			user.setPassword(password);
			user.setSex(sex);
			user.setDate(date);
			int rs=userdao.updateUserById(user);
			if(rs!=0){
				response.sendRedirect("about.jsp");
			}
			
		}
	}
	
	public static boolean equalsUsername(String username){
		boolean result=true;
		UserDao userdao=new UserDaoImpl();
		List<String> list=userdao.selectUsername();
		for(int i=0;i<list.size();i++){
			if(username.equals(list.get(i))){
				result=false;
			}else{
				result=true;
			}
		}		
		return result;
	}
	public static boolean equalsPassword(String password){
		boolean result=true;
		UserDao userdao=new UserDaoImpl();
		List<String> list=userdao.selectPassword();
		for(int i=0;i<list.size();i++){
			if(password.equals(list.get(i))){
				result=false;
			}else{
				result=true;
			}
		}		
		return result;
	}

}
