package com.servlet;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.InfoDao;
import com.dao.impl.InfoDaoImpl;
import com.entity.Info;
import com.tools.Tools;

/**
 * Servlet implementation class InfoServlet
 */
@WebServlet("/InfoServlet")
public class InfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InfoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		String para=request.getParameter("para");
		System.out.println(para);
		if(para.equals("del")){
		String id=request.getParameter("id");
		int ids=Integer.parseInt(id);
		InfoDao infodao=new InfoDaoImpl();
		int rs=infodao.delInfo(ids);
		if(rs!=0){
			response.sendRedirect("guestbook.jsp");
		}
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		InfoDao infodao=new InfoDaoImpl();
		request.setCharacterEncoding("UTF-8");
		String para=request.getParameter("para");
		if(para.equals("add")){
		System.out.println("添加");
		String message=request.getParameter("message");
		if(Tools.isChinese(message)){
		Info info=new Info();
		info.setInfo(message);
		infodao.addInfo(info);
		response.sendRedirect("guestbook.jsp");
		}else if(!Tools.isChinese(message)){
		response.sendRedirect("guestbook.html");
		}
		}
	}
	


}
