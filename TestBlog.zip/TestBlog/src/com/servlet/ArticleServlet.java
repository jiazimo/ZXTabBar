package com.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ArticleDao;
import com.dao.impl.ArticleDaoImpl;
import com.entity.Title;

/**
 * Servlet implementation class ArticleServlet
 */
@WebServlet("/ArticleServlet")
public class ArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		ArticleDao articledao=new ArticleDaoImpl();
		request.setCharacterEncoding("UTF-8");
		String para=request.getParameter("para");
		if(para.equals("del")){
			String id=request.getParameter("id");
			int ids=Integer.parseInt(id);
			int rs=articledao.delById(ids);
			if(rs!=0){
				response.sendRedirect("article.jsp");
			}
		}else if(para.equals("selectById")){
			String id=request.getParameter("id");
			int ids=Integer.parseInt(id);
			Title t=articledao.selectTitleById(ids);
			request.setAttribute("title", t);
			request.getRequestDispatcher("articleTitle.jsp").forward(request, response);
		}else if(para.equals("select")){
			String id=request.getParameter("id");
			int ids=Integer.parseInt(id);
			Title t=articledao.selectTitleById(ids);
			request.setAttribute("title", t);
			request.getRequestDispatcher("articleTitles.jsp").forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		ArticleDao articledao=new ArticleDaoImpl();
		request.setCharacterEncoding("UTF-8");
		String para=request.getParameter("para");
		if(para.equals("update")){
			String id=request.getParameter("id");
			int ids=Integer.parseInt(id);
			 String title=request.getParameter("title");
	         String author=request.getParameter("author");
	         String kind=request.getParameter("kind");
	         String date=request.getParameter("time");
	         String info=request.getParameter("message");
	         Title t=new Title();
	         t.setId(ids);
	         t.setTitle(title);
	         t.setAuthor(author);
	         t.setKind(kind);
	         t.setDate(date);
	         t.setInfo(info);
	         int rs=articledao.updateTitle(t);
	         if(rs!=0){
	        	 response.sendRedirect("article.jsp");
	         }
		}
		 
	}

}
